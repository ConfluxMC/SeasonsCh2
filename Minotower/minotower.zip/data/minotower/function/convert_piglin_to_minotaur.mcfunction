tag @s add converted
execute unless predicate minotower:in_minotower run return fail

attribute @s minecraft:scale base set 1.4