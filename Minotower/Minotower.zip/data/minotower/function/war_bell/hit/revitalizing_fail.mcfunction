function minotower:war_bell/degrade
function minotower:war_bell/degrade