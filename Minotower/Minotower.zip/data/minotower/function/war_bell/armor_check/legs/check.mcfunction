function minotower:war_bell/armor_check/legs/material
function minotower:war_bell/armor_check/legs/trim_material
function minotower:war_bell/armor_check/legs/trim_pattern