# Vanilla Advancements
advancement revoke @s[advancements={minecraft:adventure/fall_from_world_height=true}] only minecraft:adventure/fall_from_world_height
advancement revoke @s[advancements={minecraft:adventure/arbalistic=true}] only minecraft:adventure/arbalistic
advancement revoke @s[advancements={minecraft:adventure/avoid_vibration=true}] only minecraft:adventure/avoid_vibration
advancement revoke @s[advancements={minecraft:adventure/blowback=true}] only minecraft:adventure/blowback
advancement revoke @s[advancements={minecraft:adventure/brush_armadillo=true}] only minecraft:adventure/brush_armadillo
advancement revoke @s[advancements={minecraft:adventure/bullseye=true}] only minecraft:adventure/bullseye
advancement revoke @s[advancements={minecraft:adventure/craft_decorated_pot_using_only_sherds=true}] only minecraft:adventure/craft_decorated_pot_using_only_sherds
advancement revoke @s[advancements={minecraft:adventure/crafters_crafting_crafters=true}] only minecraft:adventure/crafters_crafting_crafters
advancement revoke @s[advancements={minecraft:adventure/heart_transplanter=true}] only minecraft:adventure/heart_transplanter
advancement revoke @s[advancements={minecraft:adventure/hero_of_the_village=true}] only minecraft:adventure/hero_of_the_village
advancement revoke @s[advancements={minecraft:adventure/honey_block_slide=true}] only minecraft:adventure/honey_block_slide
advancement revoke @s[advancements={minecraft:adventure/kill_a_mob=true}] only minecraft:adventure/kill_a_mob
advancement revoke @s[advancements={minecraft:adventure/kill_mob_near_sculk_catalyst=true}] only minecraft:adventure/kill_mob_near_sculk_catalyst
advancement revoke @s[advancements={minecraft:adventure/lighten_up=true}] only minecraft:adventure/lighten_up
advancement revoke @s[advancements={minecraft:adventure/minecraft_trials_edition=true}] only minecraft:adventure/minecraft_trials_edition
advancement revoke @s[advancements={minecraft:adventure/overoverkill=true}] only minecraft:adventure/overoverkill
advancement revoke @s[advancements={minecraft:adventure/read_power_of_chiseled_bookshelf=true}] only minecraft:adventure/read_power_of_chiseled_bookshelf
advancement revoke @s[advancements={minecraft:adventure/revaulting=true}] only minecraft:adventure/revaulting
advancement revoke @s[advancements={minecraft:adventure/salvage_sherd=true}] only minecraft:adventure/salvage_sherd
advancement revoke @s[advancements={minecraft:adventure/ol_betsy=true}] only minecraft:adventure/ol_betsy
advancement revoke @s[advancements={minecraft:adventure/shoot_arrow=true}] only minecraft:adventure/shoot_arrow
advancement revoke @s[advancements={minecraft:adventure/sleep_in_bed=true}] only minecraft:adventure/sleep_in_bed
advancement revoke @s[advancements={minecraft:adventure/sniper_duel=true}] only minecraft:adventure/sniper_duel
advancement revoke @s[advancements={minecraft:adventure/spear_many_mobs=true}] only minecraft:adventure/spear_many_mobs
advancement revoke @s[advancements={minecraft:adventure/spyglass_at_ghast=true}] only minecraft:adventure/spyglass_at_ghast
advancement revoke @s[advancements={minecraft:adventure/spyglass_at_parrot=true}] only minecraft:adventure/spyglass_at_parrot
advancement revoke @s[advancements={minecraft:adventure/summon_iron_golem=true}] only minecraft:adventure/summon_iron_golem
advancement revoke @s[advancements={minecraft:adventure/totem_of_undying=true}] only minecraft:adventure/totem_of_undying
advancement revoke @s[advancements={minecraft:adventure/trade=true}] only minecraft:adventure/trade
advancement revoke @s[advancements={minecraft:adventure/two_birds_one_arrow=true}] only minecraft:adventure/two_birds_one_arrow
advancement revoke @s[advancements={minecraft:adventure/under_lock_and_key=true}] only minecraft:adventure/under_lock_and_key
advancement revoke @s[advancements={minecraft:adventure/use_lodestone=true}] only minecraft:adventure/use_lodestone
advancement revoke @s[advancements={minecraft:adventure/voluntary_exile=true}] only minecraft:adventure/voluntary_exile
advancement revoke @s[advancements={minecraft:adventure/walk_on_powder_snow_with_leather_boots=true}] only minecraft:adventure/walk_on_powder_snow_with_leather_boots
advancement revoke @s[advancements={minecraft:adventure/who_needs_rockets=true}] only minecraft:adventure/who_needs_rockets
advancement revoke @s[advancements={minecraft:adventure/whos_the_pillager_now=true}] only minecraft:adventure/whos_the_pillager_now

advancement revoke @s[advancements={minecraft:husbandry/allay_deliver_cake_to_note_block=true}] only minecraft:husbandry/allay_deliver_cake_to_note_block
advancement revoke @s[advancements={minecraft:husbandry/allay_deliver_item_to_player=true}] only minecraft:husbandry/allay_deliver_item_to_player
advancement revoke @s[advancements={minecraft:husbandry/axolotl_in_bucket=true}] only minecraft:husbandry/axolotl_in_bucket
advancement revoke @s[advancements={minecraft:husbandry/feed_snifflet=true}] only minecraft:husbandry/feed_snifflet
advancement revoke @s[advancements={minecraft:husbandry/fishy_business=true}] only minecraft:husbandry/fishy_business
advancement revoke @s[advancements={minecraft:husbandry/froglights=true}] only minecraft:husbandry/froglights
advancement revoke @s[advancements={minecraft:husbandry/kill_axolotl_target=true}] only minecraft:husbandry/kill_axolotl_target
advancement revoke @s[advancements={minecraft:husbandry/leash_all_frog_variants=true}] only minecraft:husbandry/leash_all_frog_variants
advancement revoke @s[advancements={minecraft:husbandry/make_a_sign_glow=true}] only minecraft:husbandry/make_a_sign_glow
advancement revoke @s[advancements={minecraft:husbandry/plant_any_sniffer_seed=true}] only minecraft:husbandry/plant_any_sniffer_seed
advancement revoke @s[advancements={minecraft:husbandry/remove_wolf_armor=true}] only minecraft:husbandry/remove_wolf_armor
advancement revoke @s[advancements={minecraft:husbandry/repair_wolf_armor=true}] only minecraft:husbandry/repair_wolf_armor
advancement revoke @s[advancements={minecraft:husbandry/ride_a_boat_with_a_goat=true}] only minecraft:husbandry/ride_a_boat_with_a_goat
advancement revoke @s[advancements={minecraft:husbandry/safely_harvest_honey=true}] only minecraft:husbandry/safely_harvest_honey
advancement revoke @s[advancements={minecraft:husbandry/silk_touch_nest=true}] only minecraft:husbandry/silk_touch_nest
advancement revoke @s[advancements={minecraft:husbandry/tactical_fishing=true}] only minecraft:husbandry/tactical_fishing
advancement revoke @s[advancements={minecraft:husbandry/tadpole_in_a_bucket=true}] only minecraft:husbandry/tadpole_in_a_bucket
advancement revoke @s[advancements={minecraft:husbandry/tame_an_animal=true}] only minecraft:husbandry/tame_an_animal
advancement revoke @s[advancements={minecraft:husbandry/wax_off=true}] only minecraft:husbandry/wax_off
advancement revoke @s[advancements={minecraft:husbandry/wax_on=true}] only minecraft:husbandry/wax_on

advancement revoke @s[advancements={minecraft:story/cure_zombie_villager=true}] only minecraft:story/cure_zombie_villager
advancement revoke @s[advancements={minecraft:story/deflect_arrow=true}] only minecraft:story/deflect_arrow
advancement revoke @s[advancements={minecraft:story/enchant_item=true}] only minecraft:story/enchant_item

# Other Base Advancements
advancement revoke @s[advancements={conflux_seasons:visible/seasons/shop/shop=true}] only conflux_seasons:visible/seasons/shop/shop

advancement revoke @s[advancements={conflux_seasons:visible/seasons/glow_squid/brew_potion=true}] only conflux_seasons:visible/seasons/glow_squid/brew_potion
advancement revoke @s[advancements={conflux_seasons:visible/seasons/glow_squid/glow_rod=true}] only conflux_seasons:visible/seasons/glow_squid/glow_rod
advancement revoke @s[advancements={conflux_seasons:visible/seasons/glow_squid/obtain_blaze_rod=true}] only conflux_seasons:visible/seasons/glow_squid/obtain_blaze_rod

advancement revoke @s[advancements={conflux_seasons:visible/seasons/conduit=true}] only conflux_seasons:visible/seasons/conduit




# Packs
advancement revoke @s[advancements={conflux_seasons:visible/packs/weekly/fungal_caves=true}] only conflux_seasons:visible/packs/weekly/fungal_caves


# Reset the resetter
advancement revoke @s only conflux_seasons:packs_reset/daily