$execute in $(dimension) run forceload add $(x) $(z)

#$execute at @s in $(dimension) run tp $(x) $(y) $(z)
$execute at @s in $(dimension) run tp $(x) $(y_adj) $(z)

#execute at @s run playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ .5 0.5
#particle minecraft:reverse_portal ~ ~.5 ~ .3 .7 .3 0 100

$execute in $(dimension) run forceload remove $(x) $(z)