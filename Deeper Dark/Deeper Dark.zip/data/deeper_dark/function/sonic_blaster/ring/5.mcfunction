#down
summon text_display ~ ~ ~ {brightness:{sky:15,block:15},Tags:["deeper_dark.sonic_blaster_ring_5","deeper_dark.sonic_blaster_display"],background:0,line_width:800,alignment:"left",Rotation:[0F,90F],width:1f,height:1f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.4751f,0.51f],scale:[0.5f,0.5f,0f]},text:[{"color":"#00ffff","text":"                \n                \n                \n      ■         \n          ■     \n        ■       \n                \n                "}]}

summon text_display ~ ~ ~ {brightness:{sky:15,block:15},Tags:["deeper_dark.sonic_blaster_ring_5","deeper_dark.sonic_blaster_display"],background:0,line_width:800,alignment:"left",Rotation:[0F,90F],width:1f,height:1f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.05f,-0.4751f,0.51f],scale:[0.5f,0.5f,0f]},text:[{"color":"#00ffff","text":"                \n                \n                \n        ■       \n    ■           \n      ■         \n                \n                "}]}

summon text_display ~ ~ ~ {brightness:{sky:15,block:15},Tags:["deeper_dark.sonic_blaster_ring_5","deeper_dark.sonic_blaster_display"],background:0,line_width:800,alignment:"left",Rotation:[0F,90F],width:1f,height:1f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.5376000000000001f,0.51f],scale:[0.5f,0.5f,0f]},text:[{"color":"#00ffff","text":"                \n                \n        ■       \n          ■     \n      ■         \n                \n                \n                "}]}

summon text_display ~ ~ ~ {brightness:{sky:15,block:15},Tags:["deeper_dark.sonic_blaster_ring_5","deeper_dark.sonic_blaster_display"],background:0,line_width:800,alignment:"left",Rotation:[0F,90F],width:1f,height:1f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.05f,-0.5376000000000001f,0.51f],scale:[0.5f,0.5f,0f]},text:[{"color":"#00ffff","text":"                \n                \n      ■         \n    ■           \n        ■       \n                \n                \n                "}]}


#Generated with EMD's datapack texture generator 2

execute as @e[type=text_display,tag=deeper_dark.sonic_blaster_ring_5,limit=4,sort=nearest,distance=0...1] run rotate @s facing ^ ^ ^1