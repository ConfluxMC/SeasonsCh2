#gamerule commandModificationBlockLimit 2147483647
gamerule max_block_modifications 2147483647
fill ~-100 -63 ~-100 ~100 63 ~100 minecraft:air replace #deeper_dark:sculk