scoreboard objectives add rascal_can_be_caught_cooldown dummy
scoreboard objectives add rascal_stay_invis_timer dummy
scoreboard objectives add rascal_times_found dummy
scoreboard objectives add ShowArms_2_rascal_minliv dummy
scoreboard objectives add ShowArms_1_rascal_minliv dummy


#Initiate spawn attempt loop
schedule function rascal:attempt_spawn 60s