scoreboard objectives add minersHelmetForward dummy
scoreboard objectives add miners_helmet.id dummy